import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import {ConfirmDialogComponent} from "../components/confirm-dialog/confirm-dialog.component";
import {CustomerDetailsComponent} from "../components/customer-details/customer-details.component";


@Injectable({
  providedIn: 'root'
})
export class DialogService {

 
  constructor(private dialog: MatDialog) { }

  openConfirmDialog(msg){
   return this.dialog.open(ConfirmDialogComponent,{
      width: '390px',
      panelClass: 'confirm-dialog-container',
      disableClose: true,
      position: { top: "10px" },
      data :{
        message : msg
      }
    });
  }

  openForm(id){
    return this.dialog.open(CustomerDetailsComponent,{
      //autoFocus = true;
      width: '80%',
      //panelClass: 'confirm-dialog-container',
      disableClose: true,
      data :{
        message : id
      }
    //  position: { top: "10px" },
    });
  }
  // const dialogConfig = new MatDialogConfig();
  // dialogConfig.disableClose = true;
  // dialogConfig.autoFocus = true;//
  // dialogConfig.width = "80%";
  // dialogConfig.height = "60%";
  // this.dialog.open(CustomerDetailsComponent, dialogConfig);
}
