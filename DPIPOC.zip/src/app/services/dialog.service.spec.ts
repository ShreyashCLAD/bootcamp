import {async, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material';
import { DialogService } from './dialog.service';
import { ConfirmDialogComponent } from '../components/confirm-dialog/confirm-dialog.component';

describe('DialogService', () => {
  let service:DialogService;
  let dialog:MatDialog;
  let msg;
  let data={
    width: '390px',
    panelClass: 'confirm-dialog-container',
    disableClose: true,
    position: { top: "10px" },
    data :{
      message : msg
    }
  };
  beforeEach(async(() => {
    service=new DialogService(dialog);
  }));


  it('should be created', () => {
    
    const app = service;
    expect(app).toBeTruthy();
  });

  it('should open confirmDialog', () => {
    
    const app = service;
   const openDialog= app.openConfirmDialog(msg);
    expect(openDialog).toHaveBeenCalledWith(ConfirmDialogComponent,data);
  });
});
