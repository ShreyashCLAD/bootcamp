import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Customer } from "../interfaces/customer";
import { CustomerService } from './customer.service';
import { HttpClient, HttpHeaders,HttpHandler } from "@angular/common/http";
import { environment } from "../../environments/environment";
import{NotificationsService} from "./notifications.service";
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { from } from 'rxjs';
describe('CustomerDetailsComponent', () => {
  let service: CustomerService;
  let http: HttpClient;
  let details: Customer;
  let id:number;
  let snackBar: MatSnackBar;
 let handler:HttpHandler;

 let notificationsService:NotificationsService;

  beforeEach(async(() => {
    service = new CustomerService(http);
    details = <Customer>{};
    id = 0;
    http=new HttpClient(handler);
    notificationsService=new NotificationsService(snackBar);
  }));

  //will create the app 
  it('should create the app', () => {
    const app = service;
    expect(app).toBeTruthy();
  });

  //will execute postcustomer()  
  it('should run postcustomer()', () => {
    //arrange
    const app = service;
    details["cId"] = 0;
    const postcustomer = app.postCustomer(details);
    const options = {
      headers: new HttpHeaders({ "content-type": "application/json" })
    };
    expect(app.http.post<Customer[]>(
      app.baseURL + "/customer",
      details,
      options
    )).toBeTruthy();
  });

  //will execute getcustomer()    
  it('should run getcustomer()', () => {
    const app = service;
    const getcustomer = app.getCustomerList();
    const options = {
      headers: new HttpHeaders({ "content-type": "application/json" })
    };
     const getapp=app.http.get<Customer[]>(app.baseURL + "/customer",
    options,
  );
    expect(getapp).toBeTruthy();
  });

  //will execute updatecustomer()    
  it('should run updatecustomer()', () => {
    const app = service;
    const updatecustomer = app.updateCustomer(details);
    const options = {
      headers: new HttpHeaders({ "content-type": "application/json" })
    };
    expect(app.http.put(
      app.baseURL + "/customer/" + `${details.cId}`,
      details,
      options,
    )).toBeTruthy();
  });

  //will execute removecutomer()      
  it('should run removecustomer()', () => {
    const app = service;
    const removecustomer = app.removeCustomer(id);
    const options = {
      headers: new HttpHeaders({ "content-type": "application/json" })
    };
    expect(app.http.delete<Customer[]>(
      app.baseURL + "/customer/" + `${id}`,
      options,
    )).toBeTruthy();
  });

//will execute getcustomerbyid()      
   it('should run getcustomerbyid()', () => {
    const app = service;
    const getcustomerbyid = app.getCustomerbyid(id);
    const options = {
      headers: new HttpHeaders({ "content-type": "application/json" })
    };
    expect(app.http.get<Customer[]>(
      app.baseURL + "/customer/" + `${id}`,
      options,
    )).toBeTruthy();
  });
});


