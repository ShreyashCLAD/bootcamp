export class Customer {
  position: Number
   firstName: String
   DOB: string
   lastName: String
   Address:String
   country:String
   email:String
   city:String
   state:String
   pin:String
   Mobileno:Number
}
