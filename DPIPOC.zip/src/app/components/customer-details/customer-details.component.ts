import { Component, OnInit, Inject } from "@angular/core";
import { CustomerService } from "../../services/customer.service";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { NotificationsService } from "../../services/notifications.service";
import { Customer } from "../../interfaces/customer";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import * as _ from "underscore";

@Component({
  selector: "app-customer-details",
  templateUrl: "./customer-details.component.html",
  styleUrls: ["./customer-details.component.css"]
})
export class CustomerDetailsComponent implements OnInit {
  userdata: Customer[];
  datalist: Customer[];
  constructor(
     public service: CustomerService,
    @Inject(MAT_DIALOG_DATA) public data,
    public dialogRef: MatDialogRef<CustomerDetailsComponent>,
    public notificationService: NotificationsService
  ) {}

  formcid: any;

  form: FormGroup;
  ngOnInit() {
    this.service.getCustomerList().subscribe((response: Array<Customer>) => {
      this.datalist = response;
      // console.log(this.datalist, "datafom");
    });

    this.form = new FormGroup({
      firstname: new FormControl("", [
        Validators.required,
        Validators.maxLength(50)
      ]),
      lastname: new FormControl("", [
        Validators.required,
        Validators.maxLength(50)
      ]),
      email: new FormControl("", [
        Validators.email,
        Validators.required,
        Validators.maxLength(100)
      ]),
      mobileNo: new FormControl("", [
        Validators.required,
        Validators.minLength(10)
      ]),
      address: new FormControl("", [
        Validators.required,
        Validators.maxLength(100)
      ]),
      date: new FormControl("", Validators.required),
      city: new FormControl("", [
        Validators.required,
        Validators.maxLength(50)
      ]),
      state: new FormControl("", [
        Validators.required,
        Validators.maxLength(50)
      ]),
      country: new FormControl("", [
        Validators.required,
        Validators.maxLength(100)
      ]),
      cId: new FormControl(""),
      pin: new FormControl("", [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(6)
      ])
    });
    this.formcid = this.data.message;
    if (!this.formcid) {
      this.initializeFormGroup();
    }

    // if (this.formcid) {
    //   this.service
    //     .getCustomerbyid(this.formcid)
    //     .subscribe((response: Array<Customer>) => {
    //       this.userdata = response;
    //       this.populateForm(this.userdata);
    //     });
    // }

    if (this.formcid) {
      this.service
        .getCustomerbyid(this.formcid)
        .subscribe(
          res => (this.userdata = res),
          err => console.log(err.error.message),
          () => this.populateForm(this.userdata)
        );
    }
  }

  onClear() {
    this.form.reset();
    this.initializeFormGroup();
  }

  onSubmit() {
    if (this.form.valid) {
      const formData = this.form.value;
      console.log(formData);
      if (!this.form.get("cId").value) {
        this.service
          .postCustomer(formData)
          .subscribe(
            data =>
              this.notificationService.success(":: submited successfully "),
            err => this.notificationService.warn(":: email already exits"),
            () => this.onClose()
          );
      } else {
        const formData = this.form.value;
        //console.log(this.form.value.email,'shreyash')
        const email = _.findWhere(this.datalist, {
          cId: this.form.value.cId,
          email: this.form.value.email
        });
        const changedemail = _.findWhere(this.datalist, {
          email: this.form.value.email
        });

        if (email) {
          this.service
            .updateCustomer(formData)
            .subscribe(
              data =>
                this.notificationService.success(":: updated  successfully "),
              err => console.log(err),
              () => this.onClose()
            );
        }

        if (!changedemail) {
          this.service
            .updateCustomer(formData)
            .subscribe(
              data =>
                this.notificationService.success(":: updated  successfully "),
              err => console.log(err),
              () => this.onClose()
            );
        }
        if (changedemail) {
          this.notificationService.warn("Email already Exists ");
        }
      }
    }
  }

  onClose() {
    this.form.reset();
    this.initializeFormGroup();
    this.dialogRef.close("");
  }

  initializeFormGroup() {
    this.form.setValue({
      firstname: "",
      lastname: "",
      email: "",
      mobileNo: "",
      address: "",
      date: "",
      city: "",
      cId: "",
      country: "",
      pin: "",
      state: ""
    });
  }

  populateForm(customer) {
    this.form.setValue(customer);
  }
}
