// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { Router, UrlSerializer, ChildrenOutletContexts, Routes } from '@angular/router';
// import { Location } from '@angular/common';
// import { CustomerDetailsComponent } from './customer-details.component';
// import { CustomerService } from "../../services/customer.service";
// import { MatDialogRef } from "@angular/material";
// import { NotificationsService } from "../../services/notifications.service";
// import { FormGroup, FormControl, Validators } from "@angular/forms";
// import { MAT_DIALOG_DATA } from "@angular/material";
// import { HttpClient, HttpHeaders, HttpHandler } from "@angular/common/http";
// import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
// import * as _ from 'underscore';
// import { Customer } from "../../interfaces/customer";
// import { Inject, Component } from '@angular/core';
// describe('CustomerDetailsComponent', () => {
//   let component: CustomerDetailsComponent;
//   let notificationService: NotificationsService;
//   let dialogRef: MatDialogRef<CustomerDetailsComponent>;
//   let http: HttpClient;
//   let snackbar: MatSnackBar;
//   let service: CustomerService;
//   let form: FormGroup;
//   let router: Router;
//   let formcid:number;
//   let matdata;
//   let userdata: Customer[];
//   let datalist: Customer[];
//   let firstname;
//   let lastname;
//   let address;
//   let email;
//   let mobileNo;
//   let date;
//   let city;
//   let cId;
//   let country;
//   let state;
//   let pin;
 
//   let data: {
//     firstname: "",
//     lastname: "",
//     email: "",
//     mobileNo: "",
//     address: "",
//     date: "",
//     city: "",
//     cId: "",
//     country: "",
//     pin: "",
//     state: ""
//   }
//   beforeEach(async(() => {

//     component = new CustomerDetailsComponent(service, dialogRef, matdata, notificationService);
//     service = new CustomerService(http);
//     notificationService = new NotificationsService(snackbar);
//     // http=new HttpClient(handler);
//     // form=new FormGroup(firstname,lastname,email)
//     formcid = 0;
//     userdata = [];
//     datalist = [];
    
//     dialogRef=new MatDialogRef<CustomerDetailsComponent>(firstname,lastname,email,city);
//     form = new FormGroup({ firstname, lastname, email, mobileNo, address, date, city, country, pin, state });
//   }));
//   form;
//   //will create the details component
//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });


//   //will execute ngoninit()
//   it('should initialize ', () => {
//     component.ngOnInit();
//     component.service.getCustomerList().subscribe((response: Array<Customer>) => {
//       component.datalist=response;
//       expect(component.datalist).toBeTruthy();
//     });
//     // component.form = new FormGroup({ firstname, lastname, email, mobileNo, address, date, city, country, pin, state });

//     expect(component).toBeTruthy();
//   });

//   it('should check the availability of formCId', () => {
//     component.ngOnInit();
//     expect(formcid).not.toBeTruthy();
//     expect(component.initializeFormGroup()).toBeTruthy();

//   });

//   it('should execute when there is value for formcid', () => {
//     component.ngOnInit();
//     expect(formcid).toBeTruthy();
//     component.service.getCustomerbyid(component.formcid).subscribe((response: Array<Customer>) => {
//       expect(component.userdata).toEqual(response);
//       expect(component.populateForm(component.userdata)).toBeTruthy();

//     });
//   });



//   //will execute onclear()  
//   it('should clear ', () => {
//     component.onClear();
//     expect(component.initializeFormGroup()).toBeTruthy();
//   });

//   //will execute onsubmit()
//   it('should submit ', () => {
    
//     const formData = this.form.value;
//     const email = _.findWhere(this.datalist, { cId: this.form.value.cId, email: this.form.value.email, });
//     const changedemail = _.findWhere(this.datalist, { email: this.form.value.email, });
//     component.service.updateCustomer(formData).subscribe(() => {
//       expect(component.notificationService.success).toContain("updated successfully");
//       expect(component.onClose()).toBeTruthy();
//     });
   
//     expect(component.initializeFormGroup()).toBeDefined();
//     expect(component.notificationService.success).toContain("Submitted successfully");
//     expect(component.onClose()).toBeTruthy();
//   });


//   //will execute onsubmit()
//   it('should check if the form is valid or not and then post it',()=>{
//     component.onSubmit();
//       expect(component.form.valid).toBeTruthy(()=>{
//         const formData = this.form.value;
//         expect(formData).toEqual(component.form.value);
//         expect(component.form.get('cId').value).not.toBeTruthy(()=>{
//           component.service.postCustomer(formData).subscribe(() => {
//                 expect(component.notificationService.success).toContain("Submitted successfully");
//                 expect(component.service.getCustomerList()).toBeTruthy();
//                 expect(component.onClose()).toHaveBeenCalled();
//               });
//         });
        
//       });
//   })

//     it('should update the customer when post with id ',()=>{
//       component.onSubmit();
//       expect(component.form.valid).toBeTruthy(()=>{
//       const formData = this.form.value;
//       expect(formData).toEqual(component.form.value);
//       expect(component.form.get('cId').value).toBeTruthy(()=>{
//         const email = _.findWhere(this.datalist, { cId: this.form.value.cId, email: this.form.value.email, });
//           const changedemail = _.findWhere(this.datalist, { email: this.form.value.email, });
//           expect(email).toBeTruthy();
//           component.service.updateCustomer(formData).subscribe(() => {
//             expect(component.notificationService.success).toContain("updated successfully");
//           });
//           expect(changedemail).not.toBeTruthy();
//           component.service.updateCustomer(formData).subscribe(() => {
//             expect(component.notificationService.success).toContain("updated successfully");
//           });
//         });
//       });
//     })


//   //will execute onclose()
//   it('should close the dialog', () => {
//     component.onClose();
//     expect(component.initializeFormGroup()).toBeTruthy();
//     expect(component.dialogRef.close("")).toBeTruthy();
//   });


//   //will execute populateForm()  
//   it('should execute populate form ', () => {
//      component.populateForm(component.userdata);
//      let app = component.form.setValue(component.userdata);
//      expect(app).toBeTruthy();
//   });


//   //will execute initializeFormGroup()  
//   it('should execute initializeFormGroup ', () => {
//     let form: FormGroup;
//     component.initializeFormGroup();
//     expect(component.form.setValue(data)).toBeTruthy();
//   });
// });

