import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit, Inject } from "@angular/core";
import { ConfirmDialogComponent } from './confirm-dialog.component';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
describe('ConfirmDialogComponent', () => {
  let component:ConfirmDialogComponent;
 let data;
 let dialogRef: MatDialogRef<ConfirmDialogComponent>;
  beforeEach(async(() => {
    component=new ConfirmDialogComponent(data,dialogRef);
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close dialog ', () => {
    component.closeDialog();
    let dialogRefa=component.dialogRef;
    let app=dialogRefa.close(false);
    expect(app).toBeDefined();
  });
});
