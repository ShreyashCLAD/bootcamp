import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomerListComponent } from './customer-list.component';
import { CustomerService } from "../../services/customer.service";
import { MatDialog, MatDialogConfig } from "@angular/material";
import { MatTableDataSource } from "@angular/material/table";
import { DataSource } from '@angular/cdk/table';
import { MatDialogRef } from "@angular/material";
import { CustomerDetailsComponent } from '../customer-details/customer-details.component';
import { HttpClient, HttpHeaders,HttpHandler } from "@angular/common/http";
import { DialogService } from "../../services/dialog.service";
import { NotificationsService } from "../../services/notifications.service";
import { MAT_DIALOG_DATA } from "@angular/material";
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { FormGroup } from '@angular/forms';
import { Customer } from "../../interfaces/customer";


describe('CustomerListComponent', () => {
  let component: CustomerListComponent;
  let service: CustomerService;
  let anotherComponent: CustomerDetailsComponent;
  let dialog: MatDialog;
  let dialogRef: MatDialogRef<CustomerDetailsComponent>;
  let dialogservice: DialogService;
  let notificationService: NotificationsService;
  let http: HttpClient;
  let snackbar: MatSnackBar;
  let data;
  let dataFromService: Customer[];
  let editdata: Customer[];
  let form: FormGroup;
  let searchKey: String;
  let store: string;
  let handler:HttpHandler;
  let matdata;
  let emptyData: {
    address: ""
    cId: 0,
    city: "",
    country: "",
    date: "",
    email: "",
    firstname: "",
    lastname: "",
    mobileNo: "",
    pin: "", 
    state: ""
  }

  beforeEach(async(() => {
    component = new CustomerListComponent(service, dialog, dialogservice, notificationService);
    service = new CustomerService(http);
    dialogservice = new DialogService(dialog);
    anotherComponent = new CustomerDetailsComponent(service,dialogRef,matdata, notificationService);
    dialog;
    dataFromService;
    editdata;
    let dataSource: MatTableDataSource<Customer>;
    http=new HttpClient(handler);
  }));


  //will create the componenet
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  //will execute applyFilter()
  it('should filter the search', () => {
    component.applyFilter();
    let searchkey = component.searchKey;
    let filtercompo=component.dataSource.filter;
    expect(filtercompo).toBeTruthy(result => {
      expect(result).toMatch(searchkey.trim().toLowerCase())
    });
  });

  //will execute onCreate()
  it('should create dialog  ', () => {
    let dialogConfig = new MatDialogConfig();
    component.onCreate();
    expect(dialogConfig.disableClose).toBe(true);
    expect(dialogConfig.autoFocus).toBe(true);
    expect(dialogConfig.width).toBeCloseTo(70 / 100);
    expect(component.dialog.open(CustomerDetailsComponent, dialogConfig)).toBeTruthy();
  });

  //will execute onEdit()
  it('should open dialog box on edit  ', () => {
    let dialogConfig = new MatDialogConfig();
    component.onEdit(data);
    expect(dialogConfig.disableClose).toBe(true);
    expect(dialogConfig.autoFocus).toBe(true);
    expect(dialogConfig.width).toBeCloseTo(80 / 100);
    expect(dialogConfig.height).toBeCloseTo(60 / 100);
    component.dialog
      .open(CustomerDetailsComponent, dialogConfig)
      .afterClosed()
      .subscribe(() => {
        expect(component.getcustomer()).toBe();
      });
  });

  //will execute delete()
  it('open the dialog box of confirmation on delete  ', () => {
    let dialogConfig = new MatDialogConfig();
    component.delete(data);
    let row = data.cId;
    component.dialogservice
      .openConfirmDialog("Are you sure to delete this record ?")
      .afterClosed()
      .subscribe(res => {
        if (res) {
          component.service.removeCustomer(row).subscribe(
            result => { }
          );
          expect(component.notificationService.warn("! Deleted successfully")).toBeTruthy();
        }
      });
  });

  //will execute onSearchClear()
  it('should clear search', () => {
    component.onSearchClear();
    expect(component.applyFilter()).toHaveBeenCalled();
    expect(component).toBeTruthy();
  });

  //will execute ngOnInit()
  it('should initialize', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
    expect(component.getcustomer()).toBeDefined();
  });

  //will execute getcustomer()
  it('should execute getcustomer', () => {
    component.getcustomer();
    service.getCustomerList();
    component.service.getCustomerList().subscribe((response: Array<Customer>) => {
      expect(component.dataFromService).toEqual(response);
      component.dataSource = new MatTableDataSource(this.dataFromService);
      expect(component.dataSource.paginator).toEqual(component.paginator);
      expect(component.dataSource.sort).toEqual(component.sort);
    });
    expect(component).toBeTruthy();
  });
});
